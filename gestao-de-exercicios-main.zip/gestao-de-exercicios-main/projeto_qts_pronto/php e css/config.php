<?php
$host = 'localhost';
$username = 'root';
$password = '&tec77@info!';
$dbname = 'fabas';  

$conn = new mysqli($host, $username, $password, $dbname);
?>